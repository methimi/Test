"""Seed phrase and private-key detection."""

import hashlib
import re
from pathlib import Path

from .bip39_words import BIP39_WORDS_ORDERED
from .config import MAX_FILE_SIZE_MB

def _load_bip39_wordlist():
    """Geriye uyumluluk için gömülü kelime listesini set ve list olarak döndürür."""
    return set(BIP39_WORDS_ORDERED), list(BIP39_WORDS_ORDERED)


BIP39_WORDS = set(BIP39_WORDS_ORDERED)
BIP39_WORD_TO_INDEX = {w: i for i, w in enumerate(BIP39_WORDS_ORDERED)}

# Seed uzunluğuna göre (toplam_bit, checksum_bit) - BIP39 spesifikasyonu
# Her kelime 11 bit taşır. checksum_bit = toplam_bit / 33
BIP39_CHECKSUM_BITS = {
    12: 4,   # 128 bit entropy + 4 bit checksum  = 132 bit / 11 = 12 kelime
    15: 5,
    18: 6,
    21: 7,
    24: 8,   # 256 bit entropy + 8 bit checksum
}


def verify_bip39_checksum(words):
    """
    Bir kelime dizisinin GERÇEK bir BIP39 checksum'ını taşıyıp taşımadığını
    doğrular. BIP39 spesifikasyonu:
      1. Her kelime 11 bitlik bir index'e karşılık gelir (word list sırası)
      2. Kelimeler art arda bit dizisine dönüştürülür
      3. Son (checksum_bits) bit, geri kalan entropy'nin SHA256 hash'inin
         ilk (checksum_bits) bitine EŞİT olmalıdır

    Rastgele seçilmiş kelimelerin bu testi geçme ihtimali:
      12 kelime -> 1/16   (~%6.25)
      24 kelime -> 1/256  (~%0.39)

    Dönüş: True (checksum tutuyor - GERÇEK seed phrase formatı) / False
    """
    length = len(words)
    if length not in BIP39_CHECKSUM_BITS:
        return False

    try:
        indices = [BIP39_WORD_TO_INDEX[w] for w in words]
    except KeyError:
        return False

    checksum_bits = BIP39_CHECKSUM_BITS[length]
    total_bits = length * 11
    entropy_bits = total_bits - checksum_bits

    # Tüm kelime index'lerini tek bir bit dizisine (string olarak) çevir
    bits = "".join(bin(idx)[2:].zfill(11) for idx in indices)

    entropy_part = bits[:entropy_bits]
    checksum_part = bits[entropy_bits:]

    # entropy_part'ı byte dizisine çevir
    entropy_bytes = int(entropy_part, 2).to_bytes(entropy_bits // 8, byteorder="big")

    # SHA256 hash'inin ilk checksum_bits biti beklenen checksum ile eşleşmeli
    hash_digest = hashlib.sha256(entropy_bytes).digest()
    hash_bits = "".join(bin(b)[2:].zfill(8) for b in hash_digest)
    expected_checksum = hash_bits[:checksum_bits]

    return checksum_part == expected_checksum


# ---------------------------------------------------------------------------
# PRIVATE KEY TESPİTİ
# ---------------------------------------------------------------------------
# BIP39 seed phrase dışında, kullanıcılar cüzdanların HAM PRIVATE KEY'lerini
# de not defterlerine kaydedebilir. Bunlar farklı formatlarda olabilir:
#   1. WIF (Wallet Import Format)   - Base58Check, GÖMÜLÜ CHECKSUM var
#   2. xprv/xpub (BIP32 extended)   - Base58Check, GÖMÜLÜ CHECKSUM var
#   3. Ethereum 0x-hex              - "0x" + 64 hex karakter, checksum YOK
#   4. Çıplak 64 hex karakter       - checksum YOK, en zayıf sinyal
#      (herhangi bir SHA256 hash'i, commit id vb. ile karışabilir)

BASE58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
BASE58_INDEX = {c: i for i, c in enumerate(BASE58_ALPHABET)}


def base58_decode(s):
    """
    Base58 kodlu bir string'i byte dizisine çevirir. Geçersiz karakter
    varsa None döner (örn. Base58'de bulunmayan 0, O, I, l harfleri).
    """
    if not s or not all(c in BASE58_INDEX for c in s):
        return None
    num = 0
    for c in s:
        num = num * 58 + BASE58_INDEX[c]
    # Baştaki '1' karakterleri sıfır byte'a karşılık gelir
    n_leading_zeros = len(s) - len(s.lstrip("1"))
    body = num.to_bytes((num.bit_length() + 7) // 8, byteorder="big") if num > 0 else b""
    return b"\x00" * n_leading_zeros + body


def verify_base58check(s, expected_min_len=25, expected_max_len=110):
    """
    Bir Base58Check string'inin (WIF veya xprv/xpub gibi) checksum'ının
    geçerli olup olmadığını doğrular. Format: [payload][4 byte checksum],
    checksum = SHA256(SHA256(payload))'ın ilk 4 byte'ı.

    Rastgele bir Base58 string'in bu checksum'ı tesadüfen tutturma
    ihtimali yaklaşık 1/4.3 milyar (2^32) - BIP39'un 1/16 veya 1/256'sından
    ÇOK daha güçlü bir sinyaldir.
    """
    if not (expected_min_len <= len(s) <= expected_max_len):
        return False
    decoded = base58_decode(s)
    if decoded is None or len(decoded) < 5:
        return False
    payload, checksum = decoded[:-4], decoded[-4:]
    expected_checksum = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
    return checksum == expected_checksum


# WIF: 'K'/'L' ile başlayan sıkıştırılmış (52 karakter) veya '5' ile
# başlayan sıkıştırılmamış (51 karakter) formatlar en yaygınıdır.
# Testnet WIF'ler '9' veya 'c' ile başlar - onları da kapsıyoruz.
WIF_PATTERN = re.compile(r"\b[5KLc9][1-9A-HJ-NP-Za-km-z]{50,51}\b")

# xprv/xpub: BIP32 extended private/public key, her zaman "xprv" veya
# "xpub" ile başlar ve toplam 111 karakterdir.
XPRV_PATTERN = re.compile(r"\b(xprv|xpub)[1-9A-HJ-NP-Za-km-z]{107,108}\b")

# Ethereum private key: "0x" + tam 64 hex karakter
ETH_HEX_PATTERN = re.compile(r"\b0x[0-9a-fA-F]{64}\b")

# Çıplak 64 hex karakter (0x öneki yok) - EN ZAYIF sinyal, herhangi bir
# SHA256 hash'i, git commit id'si (40 hex, bu kapsam dışı) vb. ile
# karışabilir. Kelime sınırları arasında tam 64 karakter olmalı.
BARE_HEX_PATTERN = re.compile(r"\b[0-9a-fA-F]{64}\b")

# --- Solana ---
# Solana keypair'i Ed25519 tabanlıdır (Bitcoin/Ethereum'un secp256k1'inden
# farklı). Ham veri 64 byte'tır (32 byte private + 32 byte public key) ve
# iki yaygın gösterimi vardır:
#
# 1. Base58 kodlu tam keypair (cüzdan "export private key" çıktısı).
#    64 byte'ın Base58 karşılığı genelde 86-88 karakter arası olur.
#    CHECKSUM YOKTUR (WIF'ten farkı budur) - sinyal sadece uzunluk ve
#    karakter setine dayanır, bu yüzden Ethereum ile aynı güven
#    seviyesinde (ORTA) tutuyoruz.
SOLANA_BASE58_PATTERN = re.compile(r"\b[1-9A-HJ-NP-Za-km-z]{86,88}\b")

# 2. JSON array formatı - Solana CLI cüzdan dosyalarının (id.json) standart
#    biçimi: köşeli parantez içinde, virgülle ayrılmış TAM OLARAK 64 adet
#    0-255 arası tam sayı. Bu çok spesifik bir yapı olduğu için checksum
#    olmasa bile güçlü bir sinyaldir (ÇOK YÜKSEK).
SOLANA_JSON_ARRAY_PATTERN = re.compile(r"\[\s*\d{1,3}(?:\s*,\s*\d{1,3}){63}\s*\]")


def is_valid_solana_json_array(match_text):
    """
    Solana JSON array eşleşmesinin gerçekten geçerli byte değerleri
    (0-255 arası) içerdiğini doğrular. Regex zaten sayı sayısını (64)
    kontrol ediyor, bu fonksiyon her sayının aralığını doğrular.
    """
    try:
        numbers = [int(n) for n in re.findall(r"\d+", match_text)]
        return len(numbers) == 64 and all(0 <= n <= 255 for n in numbers)
    except ValueError:
        return False


def find_private_keys_in_text(text, source_label):
    """
    Bir metin içinde private key formatlarını arar. Her format için
    farklı güven seviyesi uygulanır - checksum doğrulanabilenler
    (WIF, xprv) en güvenilir, çıplak hex en zayıftır.

    Dönüş: [{"source":, "type":, "match_preview":, "confidence":, ...}, ...]

    NOT: Bulunan anahtarın kendisi ASLA tam olarak saklanmaz/gösterilmez -
    sadece ilk 4 ve son 4 karakteri (maskelenmiş önizleme) tutulur.
    """
    results = []

    def mask(s):
        if len(s) <= 10:
            return s[:2] + "…" + s[-2:]
        return s[:6] + "…" + s[-4:]

    # 1. WIF (checksum doğrulanır)
    for m in WIF_PATTERN.finditer(text):
        candidate = m.group(0)
        if verify_base58check(candidate, expected_min_len=51, expected_max_len=52):
            results.append({
                "source": source_label,
                "type": "WIF (Bitcoin private key)",
                "match_preview": mask(candidate),
                "confidence": "ÇOK YÜKSEK",
                "checksum_valid": True,
            })

    # 2. xprv/xpub (checksum doğrulanır)
    for m in XPRV_PATTERN.finditer(text):
        candidate = m.group(0)
        if verify_base58check(candidate, expected_min_len=111, expected_max_len=112):
            key_type = "xprv (BIP32 extended private key)" if candidate.startswith("xprv") \
                else "xpub (BIP32 extended public key)"
            # xpub PUBLIC anahtardır, private key değildir - daha düşük
            # önem taşır ama yine de hesap bilgisi sızdırabileceği için
            # raporlanır (daha düşük güven ile ayırt edilir)
            confidence = "ÇOK YÜKSEK" if candidate.startswith("xprv") else "ORTA"
            results.append({
                "source": source_label,
                "type": key_type,
                "match_preview": mask(candidate),
                "confidence": confidence,
                "checksum_valid": True,
            })

    # 3. Ethereum 0x-hex (checksum yok, ama format çok spesifik)
    for m in ETH_HEX_PATTERN.finditer(text):
        candidate = m.group(0)
        results.append({
            "source": source_label,
            "type": "Ethereum/EVM private key (0x-hex)",
            "match_preview": mask(candidate),
            "confidence": "ORTA",
            "checksum_valid": False,
        })

    # 4. Çıplak 64 hex (en zayıf sinyal - hash'lerle karışabilir).
    # Yalnızca 0x-hex ile ÇAKIŞMAYAN eşleşmeleri say (aksi halde her
    # Ethereum key'i burada da ikinci kez, "0x" olmadan sayılır).
    eth_spans = {m.span() for m in ETH_HEX_PATTERN.finditer(text)}

    def overlaps_eth(span):
        return any(span[0] >= e[0] and span[1] <= e[1] for e in eth_spans)

    for m in BARE_HEX_PATTERN.finditer(text):
        if overlaps_eth((m.start() - 2, m.end())):  # "0x" iki karakter önde
            continue
        candidate = m.group(0)
        results.append({
            "source": source_label,
            "type": "Ham 64-hex (private key OLABİLİR, hash de olabilir)",
            "match_preview": mask(candidate),
            "confidence": "DÜŞÜK",
            "checksum_valid": False,
        })

    # 5. Solana JSON array formatı (id.json) - checksum yok ama yapı çok
    # spesifik (tam 64 adet 0-255 arası tam sayı) olduğu için güçlü sinyal
    for m in SOLANA_JSON_ARRAY_PATTERN.finditer(text):
        candidate = m.group(0)
        if is_valid_solana_json_array(candidate):
            # Önizlemede sayıları değil, sadece dizinin uzunluğunu göster
            preview = f"[{candidate.count(',') + 1} sayılık dizi]"
            results.append({
                "source": source_label,
                "type": "Solana keypair (id.json formatı)",
                "match_preview": preview,
                "confidence": "ÇOK YÜKSEK",
                "checksum_valid": False,
            })

    # 6. Solana Base58 keypair (checksum yok, sinyal uzunluk+karakter
    # setine dayanır - WIF/xprv ile aynı karakter setini kullandığı için
    # onlarla çakışan eşleşmeleri hariç tutuyoruz)
    wif_spans = {m.span() for m in WIF_PATTERN.finditer(text)}
    xprv_spans = {m.span() for m in XPRV_PATTERN.finditer(text)}

    def overlaps_other_base58(span):
        for other in wif_spans | xprv_spans:
            if span[0] < other[1] and span[1] > other[0]:
                return True
        return False

    for m in SOLANA_BASE58_PATTERN.finditer(text):
        if overlaps_other_base58(m.span()):
            continue
        candidate = m.group(0)
        results.append({
            "source": source_label,
            "type": "Solana keypair (Base58, olası)",
            "match_preview": mask(candidate),
            "confidence": "ORTA",
            "checksum_valid": False,
        })

    return results


# Tarama ayarları
MIN_SEED_LENGTH = 12          # En kısa geçerli seed phrase uzunluğu
VALID_SEED_LENGTHS = (12, 15, 18, 21, 24)  # BIP39 standart uzunlukları
SCAN_EXTENSIONS = (".txt", ".rtf", ".csv", ".md", ".log", ".json")  # düz metin gibi okunur
# Özel işlem gerektiren formatlar (her biri ayrı fonksiyonla okunur):
#   .docx -> python-docx      .doc  -> ham metin çıkarma (kütüphanesiz)
#   .pdf  -> pypdf             .xlsx -> openpyxl
MAX_FILE_SIZE_MB = 5          # Bu boyuttan büyük dosyalar atlanır (performans)

# KATMAN 2 (satır-satır seed) için: ardışık tek-kelimelik satır bloğu bu
# uzunluğu AŞARSA, bu muhtemelen bir seed phrase not defteri değil, bir
# şifre/kelime listesidir (örn. rockyou.txt gibi dosyalar binlerce ardışık
# tek-kelimelik satır içerir). Böyle büyük bloklarda checksum'ın tesadüfen
# tutma ihtimali bile deneme sayısı arttıkça istatistiksel olarak
# gerçekleşmeye başlar, bu yüzden KATMAN 2'yi makul boyuttaki bloklarla
# sınırlıyoruz. 24 kelimelik en uzun seed + birkaç satır pay = 40 makul bir üst sınır.
MAX_SINGLE_WORD_BLOCK_FOR_LAYER2 = 40

# Ayrıca: dosya genelinde tek-kelimelik satır bloğu SAYISI çok fazlaysa
# (örn. bir şifre listesinde binlerce küçük blok olabilir), tek tek
# bloklar 40'ı aşmasa bile toplam deneme sayısı yine tesadüfi checksum
# tutmalarını istatistiksel olarak kaçınılmaz hale getirir. Bu yüzden
# dosyada belirli bir sayının üzerinde tek-kelimelik blok varsa KATMAN 2
# o dosya için tamamen devre dışı bırakılır.
MAX_SINGLE_WORD_BLOCKS_PER_FILE = 25

# --- Yanlış pozitif azaltma: dosya adı bazlı sinyaller ---
# Dosya adında bu kelimelerden biri geçiyorsa, dosyanın kelime listesi,
# çeviri dosyası, sözlük vb. olma ihtimali yüksektir - seed phrase değil.
# Checksum matematiği yine de tesadüfen tutabileceği için bu dosyaları
# TAMAMEN elemiyoruz (kaçırmak istemeyiz), sadece MAX_SINGLE_WORD_BLOCKS_PER_FILE
# zaten bu tür dosyaları büyük ölçüde eler. Bu liste ek bir güvenlik katmanı:
# sonuçta böyle bir dosyada eşleşme çıkarsa, raporda özel bir not gösterilir.
LOW_TRUST_FILENAME_HINTS = (
    "wordlist", "word_list", "dictionary", "sozluk", "sözlük",
    "translation", "ceviri", "çeviri", "lokalizasyon", "localization",
    "locale", "lang_", "_lang", "strings", "vocabulary", "kelime_listesi",
    "rockyou", "passwords", "sifreler", "şifreler",
)

# --- Yanlış pozitif azaltma: uzantı bazlı güven düşürme ---
# Bu uzantılardaki dosyalar genelde OTOMATİK ÜRETİLİR (kullanıcı elle
# yazmaz) - log dosyaları, derlenmiş/minify edilmiş kod, önbellek
# dosyaları gibi. Checksum tutsa bile buralarda gerçek bir seed phrase
# bulunma ihtimali, kullanıcının bilerek yazdığı bir .txt/.docx dosyasına
# göre daha düşüktür. Bu yüzden checksum geçse bile güven seviyesi bir
# kademe düşürülür (ÇOK YÜKSEK -> ORTA), TAMAMEN elenmez.
LOW_TRUST_EXTENSIONS = (".log",)


def get_filename_trust_note(filepath):
    """
    Bir dosya adının/uzantısının düşük-güven sinyali taşıyıp taşımadığını
    kontrol eder. Dosyayı ELEMEZ, sadece raporda gösterilecek bir not
    ve (varsa) güven düşürme bilgisi döndürür.
    """
    name_lower = Path(filepath).name.lower()
    ext_lower = Path(filepath).suffix.lower()

    if any(hint in name_lower for hint in LOW_TRUST_FILENAME_HINTS):
        return "dosya adı bir kelime listesi/sözlük/çeviri dosyasına benziyor"
    if ext_lower in LOW_TRUST_EXTENSIONS:
        return f"'{ext_lower}' uzantılı dosyalar genelde otomatik üretilir"
    return None

# Windows dışı sistemler veya hiç sürücü bulunamadığında yedek tarama
# klasörleri (get_default_scan_paths() içindeki fallback dalı).
def extract_words_from_line(line):
    """
    Tek bir satırdan kelimeleri çıkarır. Sadece harflerden oluşan
    token'ları alır (noktalama, sayı, sembol atlanır).
    """
    return re.findall(r"[a-zA-Z]+", line.lower())


def find_seed_phrase_candidates(words):
    """
    Kelime listesinde ardışık BIP39 kelime dizileri arar.
    12, 15, 18, 21 veya 24 kelimelik bloklar halinde kontrol eder.

    ÖNEMLİ: Bir ardışık BIP39-kelime bloğu beklenenden uzun olabilir
    (örn. JSON dosyalarında "seed" anahtarı da BIP39 kelimesi olduğu
    için gerçek 12 kelimelik seed'in ÖNÜNE eklenip 13 kelimelik bir
    blok oluşturabilir). Bu durumda gerçek seed bloğun herhangi bir
    yerinde (başta, ortada, sonda) olabilir - sadece blok başlangıcını
    denemek onu kaçırır. Bu yüzden blok içinde HER olası kaydırma
    pozisyonunu deniyoruz.

    Dönüş: [(start_index, length, run_length), ...]
    """
    candidates = []
    n = len(words)
    i = 0

    while i < n:
        # Bu pozisyondan başlayarak ne kadar BIP39 kelimesi ardışık geliyor?
        run_length = 0
        j = i
        while j < n and words[j] in BIP39_WORDS:
            run_length += 1
            j += 1

        # Ardışık BIP39 kelime dizisi bulundu, geçerli bir seed uzunluğu içeriyor mu?
        if run_length >= MIN_SEED_LENGTH:
            for valid_len in VALID_SEED_LENGTHS:
                if run_length >= valid_len:
                    # Blok içinde bu uzunlukta HER olası başlangıç noktasını dene
                    # (sadece blok başını değil - bkz. yukarıdaki docstring)
                    for offset in range(0, run_length - valid_len + 1):
                        candidates.append((i + offset, valid_len, run_length))
            i = j  # Bu bloğu geçtik, devam et
        else:
            i += 1

    return candidates


def calculate_confidence(run_length, checksum_valid):
    """
    Güven skoru hesaplama - artık BIP39 checksum doğrulamasına dayanıyor.

    ÖNEMLİ: "ÇOK YÜKSEK" bile %100 değildir. Checksum tutması, kelimelerin
    matematiksel olarak geçerli bir BIP39 seed formatı oluşturduğunu gösterir
    -- ama bu formatı oluşturan metnin GERÇEKTEN bir cüzdana ait olup olmadığını
    (yoksa tesadüfen/testte mi yazıldığını) hiçbir algoritma bilemez.

    Rastgele 12 kelimenin checksum'ı tesadüfen tutma ihtimali: ~1/16
    Rastgele 24 kelimenin checksum'ı tesadüfen tutma ihtimali: ~1/256
    """
    if checksum_valid:
        return "ÇOK YÜKSEK"
    elif run_length in VALID_SEED_LENGTHS:
        return "ORTA"
    elif run_length >= MIN_SEED_LENGTH:
        return "DÜŞÜK"
    return "DÜŞÜK"


def scan_text_content(text, source_label):
    """
    Bir metin bloğunu SATIR BAZLI tarar ve bulunan adayları döndürür.

    ÖNEMLİ: Her satır bağımsız olarak taranır, satırlar arası kelime
    birleştirilmez. Gerçek bir seed phrase her zaman tek satırda veya
    en fazla birkaç bitişik satırda yazılır; satır sınırlarını yok
    sayıp tüm dosyayı tek akış olarak taramak (örn. bir şifre listesi
    veya kelime listesi gibi binlerce ilgisiz satır içeren dosyalarda)
    tesadüfi eşleşmeleri ciddi şekilde artırır.
    """
    lines = text.splitlines()
    all_results = []

    # --- KATMAN 1: Satır içi tarama ---
    # Her satırın kendi içindeki ardışık BIP39 kelimelerini arar
    # (örn. "abandon ability able ... yellow" tek satırda yazılmış seed'ler)
    for line_number, line in enumerate(lines, start=1):
        words = extract_words_from_line(line)
        if len(words) < MIN_SEED_LENGTH:
            continue

        raw_candidates = find_seed_phrase_candidates(words)
        if not raw_candidates:
            continue

        # Aynı başlangıç noktasından gelen çoklu-uzunluk eşleşmelerini
        # tek bir "en uzun" kayda indir (12/24 aynı yerde bulunduysa 24'ü göster)
        best_by_start = {}
        for start, valid_len, run_length in raw_candidates:
            if start not in best_by_start or valid_len > best_by_start[start][0]:
                best_by_start[start] = (valid_len, run_length)

        for start, (valid_len, run_length) in best_by_start.items():
            candidate_words = words[start:start + valid_len]
            checksum_valid = verify_bip39_checksum(candidate_words)

            all_results.append({
                "source": source_label,
                "line_number": line_number,
                "start_word_index": start,
                "seed_length": valid_len,
                "actual_run_length": run_length,
                "checksum_valid": checksum_valid,
                "confidence": calculate_confidence(run_length, checksum_valid),
            })

    # --- KATMAN 2: Birden çok satıra bölünmüş seed'ler ---
    # Bazı kullanıcılar seed phrase'i birkaç kelimeyi bir satıra yazarak
    # not eder (örn. 12 kelime x 1 satır, veya 3 kelime x 4 satır, veya
    # 4 kelime x 3 satır gibi serbest gruplamalarla). Bunu yakalamak için:
    # ardışık KISA satırları (12 kelimeden az - zaten KATMAN 1'de tek
    # başına yakalanamayacak satırlar) birleştirip kontrol ederiz.
    # Yanlış pozitif patlamasını önlemek için (örn. bir şifre listesinde
    # de art arda kısa satırlar olabilir) bu katman SADECE checksum tutan
    # sonuçları rapora ekler - checksum tutmayan "tesadüfi BIP39 kelimesi"
    # satırları sessizce elenir.
    short_lines = []  # [(line_number, [word, word, ...]), ...] veya None (blok kırılır)
    for line_number, line in enumerate(lines, start=1):
        words_in_line = extract_words_from_line(line)
        if 1 <= len(words_in_line) < MIN_SEED_LENGTH:
            short_lines.append((line_number, words_in_line))
        else:
            short_lines.append(None)  # boş satır veya zaten uzun satır -> blok kırılır

    # Ardışık (kesintisiz) kısa-satır bloklarını grupla
    blocks = []  # [[(line_number, [word,...]), ...], ...]
    i = 0
    n = len(short_lines)
    while i < n:
        if short_lines[i] is None:
            i += 1
            continue
        block_start = i
        while i < n and short_lines[i] is not None:
            i += 1
        blocks.append(short_lines[block_start:i])

    # Dosya genelinde çok fazla kısa-satır bloğu varsa (örn. bir şifre
    # listesinde binlerce küçük blok olabilir), bu muhtemelen bir seed
    # phrase not defteri değil - KATMAN 2'yi bu dosya için tamamen atla.
    if len(blocks) > MAX_SINGLE_WORD_BLOCKS_PER_FILE:
        blocks = []

    for block in blocks:
        # Bloktaki toplam kelime sayısı çok büyükse (muhtemelen şifre/kelime
        # listesi, seed defteri değil) bu bloğu tamamen atla
        total_block_words = sum(len(w) for _, w in block)
        if total_block_words > MAX_SINGLE_WORD_BLOCK_FOR_LAYER2:
            continue

        # Bloğu düz bir kelime listesine çevir, her kelimenin hangi
        # satırdan geldiğini de ayrıca tutuyoruz
        block_words = []
        word_line_map = []  # block_words ile aynı indexte, o kelimenin satır no'su
        for line_number, words_in_line in block:
            for w in words_in_line:
                block_words.append(w)
                word_line_map.append(line_number)

        # Bu blok içinde geçerli uzunlukta pencereler dene (12/15/18/21/24)
        for valid_len in VALID_SEED_LENGTHS:
            if len(block_words) < valid_len:
                continue
            for start in range(0, len(block_words) - valid_len + 1):
                candidate_words = block_words[start:start + valid_len]
                if not all(w in BIP39_WORDS for w in candidate_words):
                    continue
                checksum_valid = verify_bip39_checksum(candidate_words)
                if not checksum_valid:
                    continue  # Katman 2'de checksum şart - yanlış pozitifi önler

                first_line = word_line_map[start]
                last_line = word_line_map[start + valid_len - 1]
                line_label = str(first_line) if first_line == last_line else f"{first_line}-{last_line}"

                all_results.append({
                    "source": source_label,
                    "line_number": line_label,
                    "start_word_index": start,
                    "seed_length": valid_len,
                    "actual_run_length": valid_len,
                    "checksum_valid": True,
                    "confidence": "ÇOK YÜKSEK",
                })

    return all_results
