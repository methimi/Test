"""Streaming scan orchestration."""

import os
import time
from pathlib import Path

from .config import WEBDAV_ENABLED
from .detectors import SCAN_EXTENSIONS, get_filename_trust_note
from .discovery import is_excluded_dir
from .readers import (
    DOCX_AVAILABLE, PDF_AVAILABLE, XLSX_AVAILABLE,
    scan_doc_file, scan_docx_file, scan_pdf_file, scan_txt_file, scan_xlsx_file,
)
from .webdav import webdav_upload

def collect_files_to_scan(scan_paths, include_docx=True, verbose=False):
    """
    Taranacak klasörlerden uygun uzantılı dosyaları buldukça yield eder.

    Liste oluşturmadığı için büyük disklerde dosya yollarının tamamını
    bellekte tutmaz ve ilk uygun dosya bulunur bulunmaz tarama başlayabilir.

    NOT: rglob() bir generator olduğu için, iterasyon sırasında (tüm
    dosyalar toplanmadan) bir PermissionError oluşursa dış try/except
    bunu yakalayamaz ve TÜM tarama o noktada çöker. Bu özellikle C:\\
    gibi geniş taramalarda (Windows\\WinSxS, System32 gibi erişimsiz
    klasörler yüzünden) kaçınılmaz olarak tetiklenir. Bunun yerine
    os.walk kullanıyoruz; o, erişilemeyen alt klasörleri onerror
    callback'i ile atlayıp devam edebiliyor.
    """
    extensions = set(ext.lower() for ext in SCAN_EXTENSIONS)
    if include_docx and DOCX_AVAILABLE:
        extensions.add(".docx")
    if include_docx:
        extensions.add(".doc")  # kütüphanesiz, yaklaşık metin çıkarma ile okunur
    if PDF_AVAILABLE:
        extensions.add(".pdf")
    if XLSX_AVAILABLE:
        extensions.add(".xlsx")

    skipped_dirs = [0]  # mutable closure için liste
    found_count = 0

    def on_walk_error(os_error):
        skipped_dirs[0] += 1

    for base_path in scan_paths:
        base_path = Path(base_path)
        if not base_path.exists():
            continue
        for dirpath, dirnames, filenames in os.walk(
            base_path, onerror=on_walk_error, followlinks=False
        ):
            # Dışlanan klasörlere hiç inme (os.walk'ın dirnames listesini
            # yerinde değiştirmesi, o alt klasörlere girmesini engeller -
            # sadece sonucu filtrelemekten çok daha hızlıdır)
            dirnames[:] = [d for d in dirnames if not is_excluded_dir(d)]

            for fname in filenames:
                if os.path.splitext(fname)[1].lower() in extensions:
                    found_count += 1
                    if verbose and found_count % 2000 == 0:
                        pass
                    yield Path(dirpath) / fname

    if verbose and skipped_dirs[0] > 0:
        pass


def run_scan(scan_paths, include_docx=True, verbose=True):
    """Ana tarama fonksiyonu. Tüm dosyaları tarar ve sonuçları döndürür."""
    if verbose:
        pass
    files = collect_files_to_scan(scan_paths, include_docx=include_docx, verbose=verbose)

    if verbose:
        if not DOCX_AVAILABLE and include_docx:
            print("[!] 'python-docx' kütüphanesi bulunamadı, .docx dosyaları atlanacak.")
            print("    Kurulum için: pip install python-docx")
        if not PDF_AVAILABLE:
            print("[!] 'pypdf' kütüphanesi bulunamadı, .pdf dosyaları atlanacak.")
            print("    Kurulum için: pip install pypdf")
        if not XLSX_AVAILABLE:
            print("[!] 'openpyxl' kütüphanesi bulunamadı, .xlsx dosyaları atlanacak.")
            print("    Kurulum için: pip install openpyxl")

    all_results = []
    all_key_results = []
    scanned_count = 0
    upload_stats = {"uploaded": 0, "skipped": 0, "failed": 0}
    scan_start_time = time.monotonic()

    # Uzantıya göre doğru okuyucu fonksiyona yönlendir
    SCANNER_BY_EXTENSION = {
        ".docx": scan_docx_file,
        ".doc": scan_doc_file,
        ".pdf": scan_pdf_file,
        ".xlsx": scan_xlsx_file,
    }

    for filepath in files:
        scanned_count += 1
        if verbose and scanned_count % 200 == 0:
            elapsed = time.monotonic() - scan_start_time
            rate = scanned_count / elapsed if elapsed > 0 else 0
            if elapsed >= 60:
                elapsed_str = f"{elapsed / 60:.1f} dk"
            else:
                elapsed_str = f"{elapsed:.1f} sn"

        scanner_fn = SCANNER_BY_EXTENSION.get(filepath.suffix.lower(), scan_txt_file)
        results, key_results = scanner_fn(filepath)

        # Düşük-güven sinyali varsa (kelime listesi/sözlük dosya adı,
        # veya otomatik-üretilmiş uzantı) sonuçlara not ekle ve
        # ÇOK YÜKSEK güveni bir kademe düşür (ORTA'ya). Dosya elenmiyor,
        # sadece kullanıcıya "bu daha şüpheli bir bağlamda bulundu" bilgisi
        # veriliyor. Aynı not private key sonuçlarına da uygulanır.
        trust_note = get_filename_trust_note(filepath) if (results or key_results) else None
        if trust_note:
            for r in results:
                r["low_trust_note"] = trust_note
                if r["confidence"] == "ÇOK YÜKSEK":
                    r["confidence"] = "ORTA"
            for r in key_results:
                r["low_trust_note"] = trust_note
                if r["confidence"] == "ÇOK YÜKSEK":
                    r["confidence"] = "ORTA"

        all_results.extend(results)
        all_key_results.extend(key_results)

        # WebDAV upload: ÇOK YÜKSEK eşleşme varsa anında upload
        if WEBDAV_ENABLED and (results or key_results):
            has_very_high = any(r["confidence"] == "ÇOK YÜKSEK" for r in results + key_results)
            if has_very_high:
                upload_status = webdav_upload(filepath)
                if upload_status in upload_stats:
                    upload_stats[upload_status] += 1

    if verbose:
        total_elapsed = time.monotonic() - scan_start_time
        if total_elapsed >= 60:
            elapsed_str = f"{total_elapsed / 60:.1f} dakika"
        else:
            elapsed_str = f"{total_elapsed:.1f} saniye"

    return all_results, all_key_results, scanned_count, upload_stats

