"""Filesystem and Windows drive discovery."""

import os
import re
import socket
import sys
from pathlib import Path

from .paths import get_user_dir

DEFAULT_SCAN_FOLDERS = ["Desktop", "Documents", "Downloads"]

# Varsayılan tarama kökü: tüm sistem sürücüsü
DEFAULT_SCAN_ROOT = "C:\\"

# --- Otomatik dışlanan klasörler ---
# C:\ taramasında bu klasörler KULLANICI VERİSİ BARINDIRMAZ (yalnızca
# işletim sistemi, yüklü programlar, önbellek, geçici dosyalar vb.
# içerirler) ve taranmaları hem zaman kaybı hem de gereksiz gürültü
# (log/config dosyalarında rastgele BIP39-benzeri kelime örtüşmesi)
# kaynağıdır. Yol içinde (case-insensitive) bu isimlerden biri TAM BİR
# KLASÖR ADI olarak geçiyorsa, o klasör ve altındaki her şey atlanır.
EXCLUDED_FOLDER_NAMES = {
    # İşletim sistemi
    "windows", "winsxs", "system32", "syswow64", "system volume information",
    "$recycle.bin", "recovery", "boot", "perflogs", "msocache",
    "$sysreset",
    # Program/uygulama klasörleri (kullanıcı verisi değil, kurulu yazılım)
    "program files", "program files (x86)", "programdata",
    "windowsapps", "common files",
    # Paket yöneticileri / geliştirici bağımlılıkları (binlerce küçük dosya,
    # kullanıcı verisi değil, tarama süresini ciddi uzatır)
    "node_modules", "site-packages", "dist-packages", "vendor",
    ".git", ".svn", ".hg",
    ".npm", ".nuget", ".gradle", ".cargo", ".m2", "pip", "__pycache__",
    # Önbellek / geçici / paket yöneticisi klasörleri
    "appdata", "temp", "tmp", "cache", "$windows.~bt", "$windows.~ws",
    "windows.old",
    # Tarayıcı profil önbellekleri (seed içermez, sadece binlerce küçük
    # dosya - Chrome/Edge/Firefox/Brave hepsi bu adları kullanır)
    "cache2", "gpucache", "code cache", "script cache", "cachestorage",
    "service worker",
    # Bulut senkronizasyon meta-klasörleri (senkron durumu, seed değil)
    ".dropbox.cache", ".dropbox",
    # Oyun/uygulama kurulum klasörleri (devasa binary, kullanıcı verisi değil)
    "steamapps", "steam",
    # Sanal makine / konteyner disk imajları (varsa, devasa dosyalar)
    "virtualbox vms", "vmware",
}

# Tam klasör adı eşleşmesi yetmez, bazı yollar bu isimleri İÇERİR ama tam
# eşleşmez (örn. "OneDrive - Şirket Adı"). Bunlar için "içinde geçiyorsa"
# eşleştirme kullanılır (daha agresif, ama bu isimler zaten kullanıcı
# verisiyle örtüşme ihtimali çok düşük özel isimlerdir).
EXCLUDED_FOLDER_SUBSTRINGS = (
    "$recycle.bin",
)


def is_excluded_dir(dirname):
    """
    Bir klasör adının (tam yol değil, sadece o seviyedeki isim) otomatik
    dışlama listesine girip girmediğini kontrol eder.
    """
    name_lower = dirname.lower()
    if name_lower in EXCLUDED_FOLDER_NAMES:
        return True
    return any(sub in name_lower for sub in EXCLUDED_FOLDER_SUBSTRINGS)


IGNORE_FILENAME = "scanner_ignore.txt"


def load_ignore_file():
    """
    Script/exe ile aynı klasörde 'scanner_ignore.txt' dosyası
    varsa, içindeki her satırı ek dışlama klasör adı olarak okur.
    Böylece her çalıştırmada --exclude tekrar tekrar yazmak yerine
    kalıcı bir liste tutulabilir.

    Format: her satırda bir klasör adı (yol değil, sadece isim - aynı
    EXCLUDED_FOLDER_NAMES mantığı). '#' ile başlayan satırlar ve boş
    satırlar yok sayılır.

    Dönüş: [klasör_adı, ...] (küçük harfe çevrilmemiş, ham haliyle)
    """
    ignore_path = get_user_dir() / IGNORE_FILENAME

    if not ignore_path.exists():
        return []

    entries = []
    try:
        with open(ignore_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                entries.append(line)
    except (PermissionError, OSError):
        return []

    return entries


def get_all_drives():
    """
    Sistemde bağlı TÜM sürücüleri tespit eder: iç disk (C:, D: gibi
    ek partisyonlar), USB/harici disk, ve harfe bağlanmış ağ sürücüleri
    (örn. Z:\\ olarak bağlanmış bir paylaşım). A'dan Z'ye her sürücü
    harfini dener, var olanları döndürür.

    NOT: Bağlı olmayan bir ağ sürücüsü (örn. VPN kapalıyken bağlanmış
    bir Z:\\ sürücüsü) erişim denemesinde uzun süre takılabilir. Bunu
    önlemek için her sürücüyü ayrı bir thread'de, kısa bir zaman aşımı
    ile kontrol ediyoruz - yanıt vermeyen sürücüler atlanır.
    """
    import string
    import concurrent.futures

    def check_drive(letter):
        path = Path(f"{letter}:\\")
        try:
            if path.exists():
                return path
        except OSError:
            pass
        return None

    drives = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=26) as executor:
        futures = {executor.submit(check_drive, l): l for l in string.ascii_uppercase}
        for future in concurrent.futures.as_completed(futures, timeout=30):
            try:
                result = future.result(timeout=3)
                if result:
                    drives.append(result)
            except (concurrent.futures.TimeoutError, OSError):
                continue  # yanıt vermeyen (örn. kopuk ağ sürücüsü) sürücüyü atla

    return sorted(drives, key=lambda p: str(p))


def get_mapped_network_locations():
    """
    Windows'ta daha önce bağlanılmış ağ konumlarını iki kaynaktan okur:

    1. HKEY_CURRENT_USER\\Network — sürücü harfi ATANMIŞ ağ sürücüleri
       (net use Z: \\\\sunucu\\paylasim gibi bağlananlar). RemotePath
       değeri UNC yolunu verir.

    2. Shell Network Shortcuts klasörü —
       %APPDATA%\\Microsoft\\Windows\\Network Shortcuts\\
       "Bu Bilgisayar > Ağdaki konumlar" bölümünde görünen, sürücü harfi
       OLMAYAN ağ konumu kısayolları (NAS, USB-over-network, FTP vb.).
       Her biri bir alt klasördür; içindeki target.lnk veya desktop.ini
       dosyasından UNC/URL yolu okunur.

    Sürücü harfi almış ağ sürücüleri zaten get_all_drives() ile taranıyor —
    bu fonksiyon o listeye EK olarak harfsiz ağ konumlarını ekler.

    Erişilemeyen/yanıt vermeyen konumlar zaman aşımıyla atlanır.
    """
    if sys.platform != "win32":
        return []

    try:
        import winreg
    except ImportError:
        return []

    unc_paths = set()

    # --- KAYNAK 1: HKEY_CURRENT_USER\Network (sürücü harfli ağ sürücüleri) ---
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Network") as network_key:
            i = 0
            while True:
                try:
                    subkey_name = winreg.EnumKey(network_key, i)
                except OSError:
                    break
                i += 1
                try:
                    with winreg.OpenKey(network_key, subkey_name) as subkey:
                        remote_path, _ = winreg.QueryValueEx(subkey, "RemotePath")
                        if remote_path:
                            unc_paths.add(remote_path)
                except OSError:
                    continue
    except OSError:
        pass

    # --- KAYNAK 2: Shell Network Shortcuts klasörü ---
    # %APPDATA%\Microsoft\Windows\Network Shortcuts\ altında her alt klasör
    # bir ağ konumunu temsil eder. İçindeki desktop.ini dosyasının
    # [.ShellClassInfo] bölümündeki "TargetFolderPath" veya doğrudan
    # klasör adı UNC yolunu içerebilir.
    try:
        network_shortcuts_dir = (
            Path(os.environ.get("APPDATA", ""))
            / "Microsoft" / "Windows" / "Network Shortcuts"
        )
        if network_shortcuts_dir.exists():
            for entry in network_shortcuts_dir.iterdir():
                if not entry.is_dir():
                    continue

                # Yöntem A: desktop.ini içinden TargetFolderPath oku
                desktop_ini = entry / "desktop.ini"
                if desktop_ini.exists():
                    try:
                        import configparser
                        cfg = configparser.ConfigParser()
                        cfg.read(str(desktop_ini), encoding="utf-8")
                        target = cfg.get(
                            ".ShellClassInfo", "TargetFolderPath", fallback=None
                        )
                        if target and (target.startswith("\\\\") or
                                       target.startswith("//")):
                            unc_paths.add(target)
                            continue
                    except Exception:
                        pass

                # Yöntem B: target.lnk dosyasından UNC yolunu oku
                # (Windows Shell Link — binary format, sadece UNC prefix
                # içerip içermediğini kontrol ediyoruz)
                target_lnk = entry / "target.lnk"
                if target_lnk.exists():
                    try:
                        with open(target_lnk, "rb") as f:
                            data = f.read()
                        # .lnk dosyasında UNC yolları \\ ile başlar
                        # UTF-16LE veya ASCII olarak kodlanmış olabilir
                        for encoding in ("utf-16-le", "latin-1"):
                            try:
                                text = data.decode(encoding, errors="ignore")
                                for token in text.split("\x00"):
                                    token = token.strip()
                                    if token.startswith("\\\\") and len(token) > 4:
                                        unc_paths.add(token)
                                        break
                            except Exception:
                                continue
                    except (PermissionError, OSError):
                        pass
    except Exception:
        pass

    if not unc_paths:
        return []

    # Her konumun erişilebilir olup olmadığını zaman aşımıyla kontrol et
    import concurrent.futures

    def check_unc(path_str):
        path = Path(path_str)
        try:
            if path.exists():
                return path
        except OSError:
            pass
        return None

    reachable = []
    with concurrent.futures.ThreadPoolExecutor(
        max_workers=max(len(unc_paths), 1)
    ) as executor:
        futures = {executor.submit(check_unc, p): p for p in unc_paths}
        for future in concurrent.futures.as_completed(futures, timeout=30):
            try:
                result = future.result(timeout=5)
                if result:
                    reachable.append(result)
            except (concurrent.futures.TimeoutError, OSError):
                continue

    return sorted(reachable, key=lambda p: str(p))


def get_default_scan_paths():
    """
    Varsayılan tarama köklerini döndürür. Artık sistemde bağlı TÜM
    sürücüler taranıyor - iç diskler, USB/harici diskler, harfe bağlı
    ağ sürücüleri (örn. Z:\\), ve daha önce bağlanılmış (harfsiz) ağ
    konumları (Network Locations / UNC kısayolları). Sistem/program
    klasörleri collect_files_to_scan içindeki is_excluded_dir()
    kontrolüyle her konumda ayrı ayrı otomatik atlanır.

    Ağdaki bilinmeyen bilgisayarlar/paylaşımlar TARANMAZ - sadece
    kullanıcının daha önce bilerek bağlandığı (kayıt defterinde kayıtlı)
    konumlar otomatik dahil edilir. Hiç bağlanılmamış bir ağ paylaşımı
    için --path \\\\sunucu\\paylasim şeklinde elle belirtmek gerekir.
    """
    if sys.platform == "win32":
        drives = get_all_drives()
        network_locations = get_mapped_network_locations()

        if network_locations:
            pass

        all_paths = drives + network_locations
        if all_paths:
            return all_paths

    # Windows değilse veya hiç sürücü bulunamadıysa (beklenmez ama
    # güvenlik amaçlı) C:\ yoluna, o da yoksa kullanıcı klasörlerine düş
    root = Path(DEFAULT_SCAN_ROOT)
    if root.exists():
        return [root]
    home = Path.home()
    paths = []
    for folder in DEFAULT_SCAN_FOLDERS:
        candidate = home / folder
        if candidate.exists():
            paths.append(candidate)
    return paths
