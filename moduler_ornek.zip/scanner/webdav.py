"""WebDAV connection, upload, and hash history."""

import datetime
import hashlib
import json
import os
import tempfile
import time
from pathlib import Path

import requests

from .config import (
    WEBDAV_ENABLED, WEBDAV_URL, WEBDAV_USER, WEBDAV_PASS, WEBDAV_HASH_LOG,
    WEBDAV_MAX_RETRIES, WEBDAV_RETRY_DELAY, WEBDAV_TIMEOUT,
)
from .geoip import get_upload_folder_name
from .paths import get_state_file, hide_state_file
from .telegram import telegram_notify_webdav_error

def _hash_log_path():
    """Hash log dosyas\u0131n\u0131n tam yolunu d\u00f6nd\u00fcr\u00fcr."""
    return get_state_file(WEBDAV_HASH_LOG)


def load_hash_log():
    """
    Daha önce upload edilmiş dosyaların SHA256 hash kümesini yükler.
    Format: ["sha256hex...", "sha256hex...", ...]  (JSON list → Python set)

    Geriye dönük uyumluluk: eski sürümde {"dosya_yolu": "sha256hex"} dict
    formatında kaydedilmiş bir log varsa, değerleri alıp set'e dönüştürür.
    Dönüş: set of SHA256 hex strings
    """
    log_path = _hash_log_path()
    if not log_path.exists():
        return set()
    try:
        import json
        with open(log_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):   # eski format: {"yol": "hash"}
            return set(data.values())
        if isinstance(data, list):   # yeni format: ["hash", ...]
            return set(data)
        return set()
    except Exception:
        return set()


def save_hash_log(log):
    """
    Hash kümesini atomik olarak diske yazar.

    Veri önce hedefle aynı klasörde geçici bir dosyaya yazılır, flush/fsync
    ile diske aktarılır ve os.replace() ile tek işlemde gerçek logun yerine
    geçirilir. Program yazma sırasında kapanırsa önceki sağlam log korunur.

    Dönüş: başarı durumunda True, hata durumunda False.
    """
    import json
    temp_path = None
    try:
        log_path = _hash_log_path()
        log_path.parent.mkdir(parents=True, exist_ok=True)

        # os.replace() yalnızca aynı dosya sistemi içinde güvenilir biçimde
        # atomiktir; bu nedenle geçici dosyayı log ile aynı klasörde oluştur.
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=log_path.parent,
            prefix=f".{log_path.name}.",
            suffix=".tmp",
            delete=False,
        ) as f:
            temp_path = Path(f.name)
            json.dump(sorted(log), f, ensure_ascii=False, indent=2)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())

        os.replace(temp_path, log_path)
        temp_path = None
        hide_state_file(log_path)
        return True
    except (PermissionError, OSError) as e:
        return False
    finally:
        # replace öncesi hata oluşursa yarım geçici dosyayı bırakma.
        if temp_path is not None:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass


def compute_file_sha256(filepath):
    """
    Bir dosyanın SHA256 hash'ini hesaplar.
    Dönüş: hex string veya hata durumunda None
    """
    try:
        h = hashlib.sha256()
        with open(filepath, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except (PermissionError, OSError):
        return None


# Oturum boyunca bellekte tutulan hash log (her upload sonrası diske de yazılır)
_HASH_LOG = None


def get_hash_log():
    """Hash log'u (set) döndürür; ilk çağrıda diskten yükler."""
    global _HASH_LOG
    if _HASH_LOG is None:
        _HASH_LOG = load_hash_log()
    return _HASH_LOG


def webdav_test_connection():
    """
    Tarama başlamadan önce WebDAV sunucusuna basit bir OPTIONS isteği
    atarak bağlantıyı ve kimlik bilgilerini doğrular.

    OPTIONS, sunucunun desteklediği metodları listeleyen standart bir
    WebDAV/HTTP isteğidir — herhangi bir dosya oluşturmaz/değiştirmez.
    Bağlantı testi için idealdir.

    Dönüş: (True, None) başarılı
            (False, hata_mesajı) başarısız
    """
    test_url = WEBDAV_URL.rstrip("/") + "/"
    try:
        response = requests.request(
            "OPTIONS", test_url,
            auth=(WEBDAV_USER, WEBDAV_PASS),
            timeout=WEBDAV_TIMEOUT,
            verify=True,
        )
        # Yalnızca WebDAV bağlantı testi için beklenen yanıtları başarı say.
        # Önceki davranış 404, 405 ve diğer 4xx kodlarını da başarılı kabul
        # ediyordu; bu da taramanın geçersiz bir hedefle başlamasına yol açıyordu.
        if response.status_code in (200, 204, 207):
            return True, None
        if response.status_code == 401:
            return False, ("Kimlik doğrulama başarısız (401). "
                           "WEBDAV_USER ve WEBDAV_PASS değerlerini kontrol edin.")
        if response.status_code == 403:
            return False, f"Erişim reddedildi (403): {test_url}"
        if response.status_code == 404:
            return False, f"WebDAV adresi bulunamadı (404): {test_url}"
        if response.status_code == 405:
            return False, ("WebDAV bağlantı testi desteklenmiyor (405 OPTIONS): "
                           f"{test_url}")
        if 300 <= response.status_code < 400:
            return False, (f"Beklenmeyen yönlendirme ({response.status_code}): "
                           f"{test_url}")
        if response.status_code >= 500:
            return False, f"Sunucu hatası ({response.status_code}): {test_url}"
        return False, (f"Beklenmeyen HTTP yanıtı ({response.status_code}): "
                       f"{test_url}")

    except requests.exceptions.SSLError as e:
        return False, f"SSL sertifika hatası: {e}"
    except requests.exceptions.ConnectionError as e:
        return False, f"Sunucuya bağlanılamadı: {e}"
    except requests.exceptions.Timeout:
        return False, f"Bağlantı zaman aşımına uğradı ({WEBDAV_TIMEOUT}s): {test_url}"
    except Exception as e:
        return False, f"Beklenmedik hata: {e}"


def _webdav_do_request(method, url, **kwargs):
    """
    Tek bir WebDAV isteğini WEBDAV_MAX_RETRIES kez dener.
    Retry yapılacak hatalar: ConnectionError, Timeout, 5xx sunucu hataları.
    Retry yapılMAYACAK hatalar: 401, 403, SSL hatası, beklenmedik istisna.

    Dönüş: (response | None, hata_mesajı | None)
    """
    last_error = None

    for attempt in range(1, WEBDAV_MAX_RETRIES + 1):
        try:
            response = requests.request(method, url, **kwargs)

            # Kimlik/yetki hatası — retry'da düzelmez, hemen dön
            if response.status_code in (401, 403):
                return response, None

            # Başarılı veya 4xx — olduğu gibi dön
            if response.status_code < 500:
                return response, None

            # 5xx sunucu hatası — last_error set et, tek backoff bloğuna düş
            last_error = f"Sunucu hatası {response.status_code}"

        except requests.exceptions.SSLError as e:
            return None, f"SSL hatası: {e}"                 # retry'da düzelmez

        except requests.exceptions.ConnectionError as e:
            last_error = f"Bağlantı hatası: {e}"

        except requests.exceptions.Timeout:
            last_error = "Zaman aşımı"

        except Exception as e:
            return None, f"Beklenmedik hata: {e}"           # retry'da düzelmez

        # --- Tek backoff bloğu — 5xx ve ağ hataları buraya düşer ---
        if attempt < WEBDAV_MAX_RETRIES:
            wait = (2 ** (attempt - 1)) * WEBDAV_RETRY_DELAY
            time.sleep(wait)

    return None, last_error


def webdav_upload(local_filepath):
    """
    Bir dosyayı koda gömülü WebDAV bilgileriyle upload eder.
    WEBDAV_ENABLED False ise hiçbir şey yapmaz.

    Geçici ağ/sunucu hatalarında exponential backoff ile otomatik retry
    yapar (max WEBDAV_MAX_RETRIES deneme). Kimlik bilgisi hataları (401)
    ve SSL hataları retry yapılmadan hemen raporlanır.

    Upload URL: WEBDAV_URL (WALLETS)/BilgisayarAdı_Ülke_Şehir/dosya_adı
    Dönüş: "uploaded" (başarılı), "skipped" (aynı hash daha önce yüklendi),
           "failed" (yüklenemedi) veya "disabled" (WebDAV kapalı)
    """
    if not WEBDAV_ENABLED:
        return "disabled"

    # --- Hash kontrolü: aynı içerik daha önce herhangi bir yoldan
    # upload edildiyse atla (yol bağımsız — içerik hash'i yeterli) ---
    file_hash = compute_file_sha256(local_filepath)

    if file_hash is not None:
        hash_log = get_hash_log()
        if file_hash in hash_log:
            filename = Path(local_filepath).name
            return "skipped"

    folder_name = get_upload_folder_name()

    # Üzerine yazma engellemesi: dosya adına içerik hash'inin ilk 8 karakterini
    # ekle (örn. "notlar.txt" → "notlar_a3f2c189.txt"). Böylece sunucuda aynı
    # isimli farklı dosyalar birbirini silmez.
    #
    # Aynı içerik → aynı hash → aynı uzak ad → PUT aynı baytı yazar (zararsız).
    # Değişen içerik → farklı hash → farklı ad → eski sürüm sunucuda korunur.
    # hash_log zaten aynı içeriği tekrar göndermediği için bu durum nadiren olur.
    #
    # file_hash hesaplanamadıysa (okuma hatası) tarihe göre yedek sonek kullan.
    stem   = Path(local_filepath).stem
    suffix = Path(local_filepath).suffix
    if file_hash:
        tag = file_hash[:8]
    else:
        tag = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename   = f"{stem}_{tag}{suffix}"
    dest_url   = f"{WEBDAV_URL.rstrip('/')}/{folder_name}/{filename}"
    folder_url = f"{WEBDAV_URL.rstrip('/')}/{folder_name}/"

    # Dosyayı oku (retry döngüsü dışında — dosya hatası retry'da düzelmez)
    try:
        with open(local_filepath, "rb") as f:
            file_data = f.read()
    except (PermissionError, OSError) as e:
        telegram_notify_webdav_error(
            "Dosya Okunamadı",
            str(e),
            Path(local_filepath).name,
        )
        return "failed"

    # MKCOL: hedef klasörü oluştur (zaten varsa 405/405/301 dönebilir — sorun değil)
    # MKCOL için tek bir retry yeterli, 5xx dışında başarısızlık önemli değil
    _webdav_do_request(
        "MKCOL", folder_url,
        auth=(WEBDAV_USER, WEBDAV_PASS),
        timeout=WEBDAV_TIMEOUT,
        verify=True,
    )

    # PUT: dosyayı yükle (retry mekanizmalı)
    response, err = _webdav_do_request(
        "PUT", dest_url,
        data=file_data,
        auth=(WEBDAV_USER, WEBDAV_PASS),
        headers={"Content-Type": "application/octet-stream"},
        timeout=WEBDAV_TIMEOUT,
        verify=True,
    )

    if err:
        # Tüm denemeler tükendi
        telegram_notify_webdav_error(
            "Upload Başarısız (Ağ Hatası)",
            f"{WEBDAV_MAX_RETRIES} deneme sonrası: {err}",
            filename,
        )
        return "failed"

    if response is None:
        telegram_notify_webdav_error(
            "Upload Başarısız (Yanıt Yok)",
            "Sunucudan yanıt alınamadı",
            filename,
        )
        return "failed"

    if response.status_code in (200, 201, 204):
        # Başarılı upload sonrası hash'i kümeye ekle ve diske yaz
        if file_hash is not None:
            hash_log = get_hash_log()
            hash_log.add(file_hash)
            save_hash_log(hash_log)
        return "uploaded"
    elif response.status_code == 401:
        telegram_notify_webdav_error(
            "Kimlik Doğrulama Hatası (401)",
            "WEBDAV_USER veya WEBDAV_PASS hatalı",
            filename,
        )
        return "failed"
    elif response.status_code == 403:
        telegram_notify_webdav_error(
            "Erişim Reddedildi (403)",
            dest_url,
            filename,
        )
        return "failed"
    else:
        telegram_notify_webdav_error(
            f"HTTP {response.status_code} Hatası",
            dest_url,
            filename,
        )
        return "failed"
