"""Runtime paths shared by source and PyInstaller builds."""

import os
import shutil
import sys
from pathlib import Path


def get_user_dir():
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def get_state_dir():
    """Çalışma dosyalarının tutulduğu mevcut kullanıcı veri kökü."""
    if os.name == "nt":
        state_dir = Path(
            os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")
        )
    else:
        state_dir = Path.home()

    state_dir.mkdir(parents=True, exist_ok=True)
    return state_dir


def hide_state_file(path):
    """Windows'ta çalışma dosyasına Hidden niteliği verir."""
    if os.name == "nt":
        try:
            import ctypes
            hidden = 0x02
            attrs = ctypes.windll.kernel32.GetFileAttributesW(str(path))
            if attrs != -1 and not attrs & hidden:
                ctypes.windll.kernel32.SetFileAttributesW(str(path), attrs | hidden)
        except (AttributeError, OSError):
            pass


def get_state_file(filename):
    """Dosyayı doğrudan AppData kökünde döndürür ve eski konumlardan taşır."""
    state_dir = get_state_dir()
    target = state_dir / filename
    legacy_candidates = [get_user_dir() / filename]

    if not target.exists():
        for legacy in legacy_candidates:
            if legacy != target and legacy.is_file():
                try:
                    shutil.move(str(legacy), str(target))
                    break
                except OSError as exc:
                    pass

    if target.is_file():
        hide_state_file(target)

    return target
