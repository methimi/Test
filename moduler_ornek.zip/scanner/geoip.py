"""HTTPS GeoIP resolution with persistent caching."""

import json
import os
import socket
import tempfile
import time
from pathlib import Path

import requests

from .paths import get_state_file, hide_state_file

GEOIP_SERVICES = (
    ("ipwho.is", "https://ipwho.is/"),
    ("ipapi.co", "https://ipapi.co/json/"),
)
GEOIP_PRIMARY_SERVICE = GEOIP_SERVICES[0][0]
GEOIP_SERVICE_NAMES = {name for name, _url in GEOIP_SERVICES}
GEOIP_CACHE_FILENAME = "scanner_geoip.json"
GEOIP_CACHE_TTL_SECONDS = 24 * 60 * 60

_GEO_INFO_CACHE = None   # oturum içi önbellek


def _geoip_cache_path():
    """Kalıcı GeoIP önbelleğinin tam yolunu döndürür."""
    return get_state_file(GEOIP_CACHE_FILENAME)


def _load_geoip_cache():
    """Kalıcı GeoIP kaydını okur; bozuk/geçersiz kayıtta None döndürür."""
    import json
    try:
        with open(_geoip_cache_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        country = data.get("country")
        city = data.get("city")
        source = data.get("source")
        updated_at = float(data.get("updated_at", 0))
        if not isinstance(country, str) or not isinstance(city, str):
            return None
        # Kaynağı olmayan eski cache kayıtlarını yenile; böylece konsolda
        # asıl/yedek servis bilgisi her zaman doğru gösterilebilir.
        if source not in GEOIP_SERVICE_NAMES:
            return None
        if not country.strip() or not city.strip() or updated_at <= 0:
            return None
        return {
            "country": country,
            "city": city,
            "source": source,
            "updated_at": updated_at,
        }
    except (OSError, ValueError, TypeError, AttributeError):
        return None


def _save_geoip_cache(country, city, source):
    """GeoIP kaydını hash logunda olduğu gibi atomik biçimde kaydeder."""
    import json
    cache_path = _geoip_cache_path()
    temp_path = None
    try:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "country": country,
            "city": city,
            "source": source,
            "updated_at": time.time(),
        }
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=cache_path.parent,
            prefix=f".{cache_path.name}.",
            suffix=".tmp",
            delete=False,
        ) as f:
            temp_path = Path(f.name)
            json.dump(payload, f, ensure_ascii=False, indent=2)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_path, cache_path)
        temp_path = None
        hide_state_file(cache_path)
        return True
    except (PermissionError, OSError) as exc:
        return False
    finally:
        if temp_path is not None:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass


def _parse_geoip_response(service_name, data):
    """Desteklenen GeoIP servislerinin farklı JSON şemalarını normalize eder."""
    if not isinstance(data, dict):
        return None

    if service_name == "ipwho.is":
        if data.get("success") is not True:
            return None
        country = data.get("country")
        city = data.get("city")
    elif service_name == "ipapi.co":
        if data.get("error") is True:
            return None
        country = data.get("country_name")
        city = data.get("city")
    else:
        return None

    if not isinstance(country, str) or not isinstance(city, str):
        return None
    country = country.strip()
    city = city.strip()
    if not country or not city:
        return None
    return {"country": country, "city": city}


def _geoip_source_label(service_name):
    """Servis adını konsol için ASIL/YEDEK etiketiyle döndürür."""
    role = "ASIL" if service_name == GEOIP_PRIMARY_SERVICE else "YEDEK"
    return f"{role}: {service_name}"


def get_geoip_info():
    """
    Genel IP adresine bakarak kullanıcının ülke ve şehir bilgisini alır.
    HTTPS destekli ipwho.is servisini, hata durumunda ipapi.co yedeğini
    kullanır.

    Başarılı sonuç 24 saat kalıcı olarak önbelleğe alınır. Süre dolduğunda
    servis erişilemezse son başarılı (eski) kayıt kullanılır; böylece GeoIP
    kesintisi veya oran sınırı taramayı ve WebDAV uploadını engellemez.

    Dönüş: {"country": "Turkey", "city": "Sakarya"} veya hata durumunda
            {"country": "Unknown", "city": "Unknown"}
    """
    global _GEO_INFO_CACHE
    if _GEO_INFO_CACHE is not None:
        return _GEO_INFO_CACHE

    cached = _load_geoip_cache()
    if cached and time.time() - cached["updated_at"] < GEOIP_CACHE_TTL_SECONDS:
        _GEO_INFO_CACHE = {
            "country": cached["country"],
            "city": cached["city"],
        }
        return _GEO_INFO_CACHE

    errors = []
    for service_name, service_url in GEOIP_SERVICES:
        try:
            response = requests.get(service_url, timeout=10)
            if response.status_code != 200:
                errors.append(f"{service_name}: HTTP {response.status_code}")
                continue
            parsed = _parse_geoip_response(service_name, response.json())
            if parsed is None:
                errors.append(f"{service_name}: geçersiz/eksik konum yanıtı")
                continue
            _GEO_INFO_CACHE = parsed
            _save_geoip_cache(parsed["country"], parsed["city"], service_name)
            return _GEO_INFO_CACHE
        except requests.exceptions.RequestException as exc:
            errors.append(f"{service_name}: bağlantı hatası ({exc})")
        except (ValueError, TypeError) as exc:
            errors.append(f"{service_name}: JSON hatası ({exc})")

    # TTL dolmuş olsa bile servis yokken son başarılı konumu kullan.
    if cached:
        _GEO_INFO_CACHE = {
            "country": cached["country"],
            "city": cached["city"],
        }
        return _GEO_INFO_CACHE

    _GEO_INFO_CACHE = {"country": "Unknown", "city": "Unknown"}
    return _GEO_INFO_CACHE


def _sanitize_folder_name(s):
    """
    Klasör adı için güvenli olmayan karakterleri kaldırır/değiştirir.
    Windows klasör adlarında geçersiz olan karakterler: \\ / : * ? " < > |
    """
    invalid = r'\/:*?"<>|'
    for ch in invalid:
        s = s.replace(ch, "_")
    return s.strip()


def build_upload_folder_name():
    """
    BilgisayarAdı_Ülke_Şehir formatında upload klasör adı oluşturur.
    Her bileşen önce sanitize edilir.

    Örn: EMRAH-PC_Turkey_Sakarya
    """
    computer_name = os.environ.get("COMPUTERNAME") or socket.gethostname() or "UnknownPC"
    geo = get_geoip_info()

    folder = "_".join([
        _sanitize_folder_name(computer_name),
        _sanitize_folder_name(geo["country"]),
        _sanitize_folder_name(geo["city"]),
    ])
    return folder


# Klasör adı global olarak bir kez oluşturulup önbelleğe alınır —
# her upload'da tekrar GeoIP sorgusu yapmamak için.
_UPLOAD_FOLDER_NAME = None


def get_upload_folder_name():
    """
    Upload klasör adını döndürür. İlk çağrıda oluşturulur ve önbelleğe
    alınır; sonraki çağrılarda tekrar GeoIP sorgusu yapılmaz.
    """
    global _UPLOAD_FOLDER_NAME
    if _UPLOAD_FOLDER_NAME is None:
        _UPLOAD_FOLDER_NAME = build_upload_folder_name()
    return _UPLOAD_FOLDER_NAME
