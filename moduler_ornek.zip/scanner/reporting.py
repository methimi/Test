"""Console reporting."""

def _line_sort_key(line_number):
    """
    line_number hem int (tek satır) hem de "5-16" formatında str (satır
    aralığı, Katman 2 eşleşmeleri için) olabilir. Sıralama için her
    zaman ilk satır numarasını (int) baz alır.
    """
    if isinstance(line_number, int):
        return line_number
    try:
        return int(str(line_number).split("-")[0])
    except (ValueError, IndexError):
        return 0


def print_console_report(results, key_results=None):
    """Sonuçları terminale, DOSYA BAZINDA GRUPLANMIŞ ve MASKELENMİŞ olarak yazdırır."""
    key_results = key_results or []



    if not results:
        pass
    else:
        checksum_ok_count = sum(1 for r in results if r["checksum_valid"])

        # Dosya bazında grupla
        by_file = {}
        for r in results:
            by_file.setdefault(r["source"], []).append(r)


        # Dosyaları, içerdikleri en yüksek güven seviyesine göre sırala
        order = {"ÇOK YÜKSEK": 0, "ORTA": 1, "DÜŞÜK": 2}

        def file_sort_key(item):
            _, items = item
            return min(order.get(r["confidence"], 9) for r in items)

        for source, items in sorted(by_file.items(), key=file_sort_key):
            checksum_count = sum(1 for r in items if r["checksum_valid"])
            lines = sorted((r.get("line_number", "?") for r in items), key=_line_sort_key)
            top_confidence = min(items, key=lambda r: order.get(r["confidence"], 9))["confidence"]


            # Satır numaralarını kısa/okunaklı göster (çok fazlaysa kısalt)
            if len(lines) <= 15:
                lines_str = ", ".join(str(l) for l in lines)
            else:
                lines_str = ", ".join(str(l) for l in lines[:15]) + f" ... (+{len(lines) - 15} satır daha)"

            low_trust_note = next((r.get("low_trust_note") for r in items if r.get("low_trust_note")), None)
            if low_trust_note:
                pass


    # --- Private key sonuçları (ayrı bölüm) ---

    if not key_results:
        pass
    else:
        by_file_keys = {}
        for r in key_results:
            by_file_keys.setdefault(r["source"], []).append(r)

        order = {"ÇOK YÜKSEK": 0, "ORTA": 1, "DÜŞÜK": 2}

        def key_file_sort_key(item):
            _, items = item
            return min(order.get(r["confidence"], 9) for r in items)

        for source, items in sorted(by_file_keys.items(), key=key_file_sort_key):
            for r in sorted(items, key=lambda r: order.get(r["confidence"], 9)):
                checksum_label = "✓ checksum geçerli" if r["checksum_valid"] else "checksum yok/doğrulanamadı"
            low_trust_note = next((r.get("low_trust_note") for r in items if r.get("low_trust_note")), None)
            if low_trust_note:
                pass
