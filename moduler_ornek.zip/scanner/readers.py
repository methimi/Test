"""Document readers for supported file formats."""

import logging
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

from .config import MAX_FILE_SIZE_MB
from .detectors import find_private_keys_in_text, scan_text_content

try:
    import docx
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False
try:
    import pypdf
    # Bozuk fakat okunabilir PDF'lerde pypdf, "Ignoring wrong pointing
    # object ..." gibi düzeltilebilir yapı uyarılarını konsola yazar.
    # Tarama sonucunu etkilemeyen bu gürültüyü gizle; gerçek hatalar kalsın.
    logging.getLogger("pypdf").setLevel(logging.ERROR)
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False
try:
    import openpyxl
    XLSX_AVAILABLE = True
except ImportError:
    XLSX_AVAILABLE = False

def scan_combined(text, source_label):
    """
    Bir metin bloğunu hem BIP39 seed phrase hem de private key formatları
    için tarar. İkisi ayrı sonuç listeleri olarak döner çünkü farklı
    veri yapılarına sahipler ve raporda ayrı bölümlerde gösterilirler.

    Dönüş: (seed_results, key_results)
    """
    seed_results = scan_text_content(text, source_label)
    key_results = find_private_keys_in_text(text, source_label)
    return seed_results, key_results


def scan_txt_file(filepath):
    """Bir .txt/.rtf dosyasını okur ve tarar."""
    try:
        size_mb = filepath.stat().st_size / (1024 * 1024)
        if size_mb > MAX_FILE_SIZE_MB:
            return [], []
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        return scan_combined(content, str(filepath))
    except (PermissionError, OSError):
        return [], []


def scan_docx_file(filepath):
    """Bir .docx dosyasını okur ve tarar (python-docx varsa)."""
    if not DOCX_AVAILABLE:
        return [], []
    try:
        size_mb = filepath.stat().st_size / (1024 * 1024)
        if size_mb > MAX_FILE_SIZE_MB:
            return [], []
        doc = docx.Document(str(filepath))
        full_text = "\n".join(p.text for p in doc.paragraphs)
        return scan_combined(full_text, str(filepath))
    except Exception:
        return [], []


def scan_pdf_file(filepath):
    """Bir .pdf dosyasını okur ve tarar (pypdf varsa)."""
    if not PDF_AVAILABLE:
        return [], []
    try:
        size_mb = filepath.stat().st_size / (1024 * 1024)
        if size_mb > MAX_FILE_SIZE_MB:
            return [], []
        reader = pypdf.PdfReader(str(filepath), strict=False)
        # Şifreli/korumalı PDF'leri atla (şifre çözmeye çalışmıyoruz)
        if reader.is_encrypted:
            return [], []
        full_text = "\n".join(page.extract_text() or "" for page in reader.pages)
        return scan_combined(full_text, str(filepath))
    except Exception:
        return [], []


def scan_xlsx_file(filepath):
    """
    Bir .xlsx dosyasını okur ve tarar (openpyxl varsa).
    Her satırdaki hücreleri boşlukla birleştirip tek satır gibi tarar,
    böylece bir seed phrase'in ayrı hücrelere yazılmış hali de yakalanabilir.
    """
    if not XLSX_AVAILABLE:
        return [], []
    try:
        size_mb = filepath.stat().st_size / (1024 * 1024)
        if size_mb > MAX_FILE_SIZE_MB:
            return [], []
        wb = openpyxl.load_workbook(str(filepath), read_only=True, data_only=True)
        text_lines = []
        for sheet in wb.worksheets:
            for row in sheet.iter_rows(values_only=True):
                cell_values = [str(c) for c in row if c is not None]
                if cell_values:
                    text_lines.append(" ".join(cell_values))
        wb.close()
        full_text = "\n".join(text_lines)
        return scan_combined(full_text, str(filepath))
    except Exception:
        return [], []


_LIBREOFFICE_PATH = None
_LIBREOFFICE_CHECKED = False
_LIBREOFFICE_FALLBACK_WARNED = False


def _find_libreoffice():
    """LibreOffice/soffice çalıştırılabilir dosyasını bir kez arar."""
    global _LIBREOFFICE_PATH, _LIBREOFFICE_CHECKED
    if _LIBREOFFICE_CHECKED:
        return _LIBREOFFICE_PATH
    _LIBREOFFICE_CHECKED = True

    candidates = [shutil.which("soffice"), shutil.which("libreoffice")]
    if os.name == "nt":
        for env_name in ("PROGRAMFILES", "PROGRAMFILES(X86)"):
            base = os.environ.get(env_name)
            if base:
                candidates.append(
                    str(Path(base) / "LibreOffice" / "program" / "soffice.exe")
                )

    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            _LIBREOFFICE_PATH = str(Path(candidate))
            break
    return _LIBREOFFICE_PATH


def _extract_doc_with_libreoffice(filepath):
    """Eski .doc dosyasını LibreOffice ile geçici UTF-8 metne dönüştürür."""
    soffice = _find_libreoffice()
    if not soffice:
        return None

    try:
        with tempfile.TemporaryDirectory(prefix="scanner_doc_") as temp_dir:
            profile_dir = Path(temp_dir) / "profile"
            output_dir = Path(temp_dir) / "output"
            profile_dir.mkdir()
            output_dir.mkdir()
            command = [
                soffice,
                "--headless",
                # Açık bir LibreOffice oturumuyla profil kilidi çakışmasını
                # önlemek için her dönüşümde ayrı geçici profil kullan.
                f"-env:UserInstallation={profile_dir.resolve().as_uri()}",
                "--convert-to", "txt:Text (encoded):UTF8",
                "--outdir", str(output_dir),
                str(Path(filepath).resolve()),
            ]
            run_kwargs = {
                "stdout": subprocess.PIPE,
                "stderr": subprocess.PIPE,
                "text": True,
                "timeout": 60,
                "check": False,
            }
            if os.name == "nt":
                run_kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
            completed = subprocess.run(command, **run_kwargs)
            output_path = output_dir / f"{Path(filepath).stem}.txt"
            if completed.returncode == 0 and output_path.is_file():
                return output_path.read_text(encoding="utf-8", errors="replace")
    except (OSError, subprocess.SubprocessError):
        pass
    return None


def _extract_doc_fallback(raw):
    """LibreOffice yokken ANSI ve UTF-16LE metin bloklarını yaklaşık çıkarır."""
    chunks = []

    for chunk in re.findall(rb"[\x20-\x7E]{4,}", raw):
        text = chunk.decode("cp1252", errors="ignore").strip()
        if text:
            chunks.append(text)

    # Eski Word belgelerinde sık görülen sıfır byte ayrımlı Unicode metin.
    utf16_pattern = rb"(?:[\x20-\x7E\xC0-\xFF]\x00){4,}"
    for chunk in re.findall(utf16_pattern, raw):
        text = chunk.decode("utf-16le", errors="ignore").strip()
        if text:
            chunks.append(text)

    return "\n".join(dict.fromkeys(chunks))


def scan_doc_file(filepath):
    """
    Eski .doc dosyasını önce LibreOffice headless dönüşümüyle tarar.
    LibreOffice yoksa veya dönüşüm başarısızsa ANSI + UTF-16LE bloklarını
    çıkaran yaklaşık yerel yöntem kullanılır.
    """
    try:
        size_mb = filepath.stat().st_size / (1024 * 1024)
        if size_mb > MAX_FILE_SIZE_MB:
            return [], []

        converted_text = _extract_doc_with_libreoffice(filepath)
        if converted_text is not None:
            return scan_combined(converted_text, str(filepath))

        global _LIBREOFFICE_FALLBACK_WARNED
        if not _LIBREOFFICE_FALLBACK_WARNED:
            if _find_libreoffice() is None:
                print("[DOC] UYARI: LibreOffice bulunamadı; .doc dosyaları "
                      "yaklaşık ANSI/UTF-16 yöntemiyle taranacak.")
            else:
                print("[DOC] UYARI: Bir .doc dosyası LibreOffice ile "
                      "dönüştürülemedi; yaklaşık yöntem kullanılacak.")
            _LIBREOFFICE_FALLBACK_WARNED = True

        with open(filepath, "rb") as f:
            raw = f.read()
        full_text = _extract_doc_fallback(raw)
        return scan_combined(full_text, str(filepath))
    except (PermissionError, OSError):
        return [], []
