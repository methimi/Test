from demo_paket.dongu import main


if __name__ == "__main__":
    main()
