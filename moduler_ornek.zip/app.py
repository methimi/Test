#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Entry point for the modular Scanner package."""

from scanner.config import *
from scanner.detectors import *
from scanner.discovery import *
from scanner.readers import *
from scanner.reporting import *
from scanner.geoip import *
from scanner.telegram import *
from scanner.webdav import *
from scanner.scanner import *
from scanner.cli import main

# Selected private helpers retained for existing integrations and diagnostics.
from scanner.detectors import _load_bip39_wordlist
from scanner.geoip import (
    _geoip_cache_path,
    _load_geoip_cache,
    _parse_geoip_response,
    _save_geoip_cache,
)
from scanner.telegram import _telegram_html
from scanner.readers import (
    _extract_doc_fallback,
    _extract_doc_with_libreoffice,
    _find_libreoffice,
)


if __name__ == "__main__":
    main()
