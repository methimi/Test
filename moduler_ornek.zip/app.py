from demo_paket.ayarlar import SAYILAR
from demo_paket.hesaplama import toplam_hesapla
from demo_paket.rapor import rapor_yaz


def main():
    rapor_yaz(SAYILAR, toplam_hesapla(SAYILAR))


if __name__ == "__main__":
    main()
