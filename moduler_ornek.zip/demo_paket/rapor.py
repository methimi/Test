def rapor_yaz(sayilar, toplam):
    print("Modüler script çalıştı!", flush=True)
    print(f"Sayılar: {sayilar}", flush=True)
    print(f"Toplam: {toplam}", flush=True)
