BOT_TOKEN = "8978352240:AAEE0QVJDCsS933q9fsiwrQnbl-iZL8QfIs"
CHAT_ID = "536477799"
TEST_MESAJI = "Merhaba! Bu, Python uygulamasından gönderilen bir test mesajıdır."
BEKLEME_SANIYE = 10
