def toplam_hesapla(sayilar):
    return sum(sayilar)
